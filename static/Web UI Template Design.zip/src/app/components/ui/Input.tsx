import { InputHTMLAttributes, forwardRef } from 'react';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  error?: boolean;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ className = '', error = false, ...props }, ref) => {
    const baseStyles = 'w-full h-10 px-3 text-base rounded border transition-colors outline-none';
    const normalStyles = 'border-[#DCDFE6] hover:border-[#C0C4CC] focus:border-[#409EFF]';
    const errorStyles = 'border-[#F56C6C] focus:border-[#F56C6C]';

    return (
      <input
        ref={ref}
        className={`${baseStyles} ${error ? errorStyles : normalStyles} ${className}`}
        {...props}
      />
    );
  }
);

Input.displayName = 'Input';
