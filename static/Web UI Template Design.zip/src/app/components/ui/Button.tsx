import { ButtonHTMLAttributes, forwardRef } from 'react';

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'text';
  size?: 'small' | 'medium' | 'large';
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'medium', className = '', children, ...props }, ref) => {
    const baseStyles = 'inline-flex items-center justify-center font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed';

    const variantStyles = {
      primary: 'bg-[#409EFF] text-white hover:bg-[#66b1ff] active:bg-[#3a8ee6]',
      secondary: 'bg-[#ecf5ff] text-[#409EFF] hover:bg-[#d9ecff] active:bg-[#b3d8ff] border border-[#b3d8ff]',
      text: 'text-[#409EFF] hover:bg-[#ecf5ff] active:bg-[#d9ecff]'
    };

    const sizeStyles = {
      small: 'h-8 px-3 text-sm rounded',
      medium: 'h-9 px-4 text-base rounded-md',
      large: 'h-10 px-5 text-base rounded-md'
    };

    return (
      <button
        ref={ref}
        className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
        {...props}
      >
        {children}
      </button>
    );
  }
);

Button.displayName = 'Button';
